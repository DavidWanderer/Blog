//
//  ViewController.m
//  PHUpdateSDKExample
//
//  Created by Hu, Yuping on 2020/2/19.
//  Copyright © 2020 江苏云学堂信息科技有限公司. All rights reserved.
//

#import "ViewController.h"
#import <PHUtils/PHUtils.h>
#import <PHUpdateSDK/PHAPPUpgradeView.h>
#import <PHUpdateSDK/PHVersionModel.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

// 非强制升级的点击事件
- (IBAction)updateAction:(UIButton *)sender {
    
    PHVersionModel *versionModel = [[PHVersionModel alloc] init];
    versionModel.appDescription = @"1. 发现模块更新；\n2. 商品详情页支持订货模式和分销模式和快速满足特定需求；\n"
    "3. 工业品超级店铺开张，欢迎使用；\n"
    "4. 其他功能优化及修复。";
    //versionModel.mustUpgrade = YES;
    [PHAPPUpgradeView showUpgradeViewOnView:PH_KEY_WINDOW withVersionModel:versionModel];
    
}

// 强制升级的点击事件
- (IBAction)forceUpdateAction:(UIButton *)sender {
    PHVersionModel *versionModel = [[PHVersionModel alloc] init];
    versionModel.appDescription = @"1. 发现模块更新；\n2. 商品详情页支持订货模式和分销模式和快速满足特定需求；\n"
    "3. 工业品超级店铺开张，欢迎使用；\n"
    "4. 其他功能优化及修复。";
    versionModel.mustUpgrade = YES;
    [PHAPPUpgradeView showUpgradeViewOnView:PH_KEY_WINDOW withVersionModel:versionModel];
}


@end
