//
//  PHUpdateSDK.h
//  PHUpdateSDK
//
//  Created by Hu, Yuping on 2020/2/19.
//  Copyright © 2020 江苏云学堂信息科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PHUpdateSDK.
FOUNDATION_EXPORT double PHUpdateSDKVersionNumber;

//! Project version string for PHUpdateSDK.
FOUNDATION_EXPORT const unsigned char PHUpdateSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PHUpdateSDK/PublicHeader.h>

#import "PHAPPUpgradeView.h"
#import "PHVersionModel.h"
