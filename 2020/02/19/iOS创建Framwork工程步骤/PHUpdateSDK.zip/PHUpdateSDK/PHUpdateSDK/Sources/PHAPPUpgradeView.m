//
//  PHAPPUpgradeView.m
//  PHMySDK
//
//  Created by Hu, Yuping on 2020/2/19.
//  Copyright © 2020 江苏云学堂信息科技有限公司. All rights reserved.
//

#import "PHAPPUpgradeView.h"
#import "PHVersionModel.h"
#import "PHUserDefaultsHandler.h"
#import <PHUtils/PHMacro.h>
#import <PHUtils/PHUtils.h>
#import <PHBizCore/PHLanguageSDK.h>

static CGFloat IMAGE_WIDTH = 312; // 升级图片的宽度
static CGFloat BUTTON_HEIGHT = 48; // 按钮的高度
static CGFloat MARGIN = 20; // 各控件之间的间距
#define UpgrateViewTag 90000

@interface PHAPPUpgradeView()
@property (strong, nonatomic) UIView *contentView;

/**
 顶部图片
 */
@property (strong, nonatomic) UIImageView *headIcon;

/**
 升级标题
 */
@property (strong, nonatomic) UILabel *titleLabel;

/**
 中间升级内容
 */
@property (strong, nonatomic) UILabel *contentLabel;

/**
 底部分割线
 */
@property (strong, nonatomic) UIView *bottomBorderLine;

/**
 底部中间分隔线
 */
@property (strong, nonatomic) UIView *bottomMidLine;

/**
 跳过按钮
 */
@property (strong, nonatomic) UIButton *skipButton;

/**
 升级按钮
 */
@property (strong, nonatomic) UIButton *upgradeButton;

@property (strong, nonatomic) UIView *subView;

@property (strong, nonatomic) PHVersionModel * versionModel;

@end

@implementation PHAPPUpgradeView

- (void)dealloc{
    NSLog(@"%s", __FUNCTION__);
}

+ (PHAPPUpgradeView *)showUpgradeViewOnView:(UIView *)baseView withVersionModel:(PHVersionModel *)versionModel
{
    NSString * skipUpgrateVersion = [PH_USERDEFAULT valueForKey:@"skipUpgrateVersion"];
    if ([versionModel.appVersionNum isEqualToString:skipUpgrateVersion] && !versionModel.mustUpgrade) {
        return nil;
    }
    
    if ([PH_KEY_WINDOW viewWithTag:UpgrateViewTag]) {
        [PH_KEY_WINDOW bringSubviewToFront:[PH_KEY_WINDOW viewWithTag:UpgrateViewTag]];
        return [PH_KEY_WINDOW viewWithTag:UpgrateViewTag];
    }
    
    PHAPPUpgradeView *upgradeView = [[PHAPPUpgradeView alloc]initWithFrame:CGRectMake(0, 0, PH_SCREEN_WIDTH, PH_SCREEN_HEIGHT)];
    [PH_KEY_WINDOW addSubview:upgradeView];
    
    upgradeView.tag = UpgrateViewTag;
    [upgradeView updateDataWithModel:versionModel];
    
    //保证键盘不弹出 遮挡升级按钮
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
    });
    
    // 保存弹窗状态
    //[PHUserDefaultsHandler setBool:YES key:kAppUpdatePopup];
    
    return upgradeView;
}

+ (PHAPPUpgradeView *)manullyShowUpgradeViewOnView:(UIView *)baseView withVersionModel:(PHVersionModel *)versionModel
{
    
    UIView *view = [PH_KEY_WINDOW viewWithTag:UpgrateViewTag];
    if (view && [view isKindOfClass:[PHAPPUpgradeView class]]) {
        PHAPPUpgradeView *upgradeView = (PHAPPUpgradeView *)view;
        [PH_KEY_WINDOW bringSubviewToFront:upgradeView]; // 将升级的弹框显示
        [upgradeView updateDataWithModel:versionModel];
        // 保存弹窗状态
        //[PHUserDefaultsHandler setBool:YES key:kAppUpdatePopup];
        
        return upgradeView;
    } else {
        PHAPPUpgradeView *upgradeView = [[PHAPPUpgradeView alloc]initWithFrame:CGRectMake(0, 0, PH_SCREEN_WIDTH, PH_SCREEN_HEIGHT)];
        [PH_KEY_WINDOW addSubview:upgradeView];
        
        upgradeView.tag = UpgrateViewTag;
        [upgradeView updateDataWithModel:versionModel];
        
        // 保存弹窗状态
        //[PHUserDefaultsHandler setBool:YES key:kAppUpdatePopup];
        
        return upgradeView;
    }
    
}

#pragma mark - lazies

- (UIView *)subView{
    if (!_subView) {
        _subView = [[UIView alloc]init];
        _subView.backgroundColor = [UIColor whiteColor];
    }
    return _subView;
}

- (UIView *)contentView{
    if(!_contentView){
        _contentView = [[UIView alloc]init];
        _contentView.layer.masksToBounds = NO;
    }
    return _contentView;
}

- (UIImageView *)headIcon{
    if(!_headIcon){
        _headIcon = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, IMAGE_WIDTH, 182)];
        _headIcon.image = [self getImageFromBundle:@"group@3x"]; //DX_KImageName(@"login_upgrade");
    }
    return _headIcon;
}

- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc]init];
    }
    return _titleLabel;
}

- (UILabel *)contentLabel{
    if (!_contentLabel) {
        _contentLabel = [[UILabel alloc]init];
    }
    return _contentLabel;
}

- (UIView *)bottomMidLine{
    if (!_bottomMidLine) {
        _bottomMidLine = [[UIView alloc]init];
    }
    return _bottomMidLine;
}


- (UIView *)bottomBorderLine{
    
    if (!_bottomBorderLine) {
        _bottomBorderLine = [[UIView alloc]init];
    }
    return _bottomBorderLine;
    
}

- (UIButton *)skipButton{
    if (!_skipButton) {
        _skipButton = [UIButton buttonWithType:(UIButtonTypeCustom)];
        [_skipButton setTitle:@"跳过" forState:(UIControlStateNormal)];
        [_skipButton setTitleColor:[UIColor ph_colorWithHexString:@"#323233"] forState:UIControlStateNormal];
        _skipButton.titleLabel.font = [UIFont systemFontOfSize:16.0];
        [_skipButton addTarget:self action:@selector(skipButtonAction) forControlEvents:(UIControlEventTouchUpInside)];
    }
    return _skipButton;
}

- (UIButton *)upgradeButton{
    if (!_upgradeButton) {
        _upgradeButton = [UIButton buttonWithType:(UIButtonTypeCustom)];
        [_upgradeButton setTitle:@"升级" forState:(UIControlStateNormal)];
        [_upgradeButton setTitleColor:[UIColor ph_colorWithHexString:@"#436BFF"] forState:UIControlStateNormal];
        [_upgradeButton setTitleColor:[UIColor ph_colorWithHexString:@"#436BFF"] forState:UIControlStateHighlighted];
        _upgradeButton.titleLabel.font = [UIFont systemFontOfSize:16.0];
        [_upgradeButton addTarget:self action:@selector(upgradeButtonAction) forControlEvents:(UIControlEventTouchUpInside)];
    }
    return _upgradeButton;
}

#pragma mark - initialize
- (instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
        
        [self initializeUI];
    }
    return self;
}

- (void)initializeUI{
    
    // 1. 头部图片
    CGFloat imgTopMargin = 0;
    self.headIcon.frame = CGRectMake(0, imgTopMargin, IMAGE_WIDTH, 182);
    self.headIcon.image = [self getImageFromBundle:@"group@3x"];
    // 2.标题
    CGFloat titleTopMargin = 35 + 60;
    CGFloat titleLeftMargin = 24;
    CGFloat titleHeight = 24;
    CGFloat titleWidth = IMAGE_WIDTH - 2*titleLeftMargin;
    self.titleLabel.frame = CGRectMake(titleLeftMargin, titleTopMargin, titleWidth, titleHeight);
    self.titleLabel.text = @"更新说明:";
    self.titleLabel.textColor = [UIColor ph_colorWithHexString:@"#323233"];
    //self.titleLabel.skin.textColor(@"color.charHightlightColor");
    self.titleLabel.font = [UIFont systemFontOfSize:16.0];
    self.titleLabel.textAlignment = NSTextAlignmentLeft;
    //self.titleLabel.ph_centerX = self.headIcon.ph_centerX;
    
    // 内容
    CGFloat contentTopMargin = 6;
    CGFloat contentLeftMargin = 24;
    CGFloat contentHeight = 120;
    self.contentLabel.frame = CGRectMake(10, self.titleLabel.ph_bottom + contentTopMargin, IMAGE_WIDTH - contentLeftMargin*2, contentHeight);
    self.contentLabel.textColor = [UIColor ph_colorWithHexString:@"#7D7E80"];
    self.contentLabel.font = [UIFont systemFontOfSize:14.0f];
    self.contentLabel.numberOfLines = -1;
    self.contentLabel.ph_centerX = self.headIcon.ph_centerX;
    // 底部分割线
    self.bottomBorderLine.backgroundColor = [UIColor ph_colorWithHexString:@"#EBEDF0"];
    // 底部中间分割线
    self.bottomMidLine.backgroundColor = [UIColor ph_colorWithHexString:@"#EBEDF0"];
    // 容器视图
    self.contentView.layer.cornerRadius = 16;
    self.contentView.layer.masksToBounds = YES;
}

#pragma mark setter and getter
- (void)updateDataWithModel:(PHVersionModel *)versionModel{
    
    _versionModel = versionModel;
    [self refreshFrameWithModel:versionModel];
}

- (void)refreshFrameWithModel:(PHVersionModel *)versionModel{
    
    // 内容高度自适应
    CGFloat contentLeftMargin = 24;
    CGFloat contentTopMargin = 6;
    CGFloat contentHeight = 120;
    self.contentLabel.frame = CGRectMake(contentLeftMargin,self.titleLabel.ph_bottom + contentTopMargin, IMAGE_WIDTH - 2*contentLeftMargin, contentHeight);
    // 设置间距
    self.contentLabel.attributedText =[self setContentMargin:versionModel.appDescription];
    //[self.contentLabel sizeToFit];
    // 底部分割线
    CGFloat borderLeftMargin = 0;
    CGFloat borderTopMargin = 24;
    CGFloat borderHeight = 1.0;
    self.bottomBorderLine.frame = CGRectMake(borderLeftMargin, self.contentLabel.ph_bottom + borderTopMargin, IMAGE_WIDTH, borderHeight);
    
    if(versionModel.mustUpgrade){
        // 强制升级
        self.upgradeButton.frame = CGRectMake(0, self.bottomBorderLine.ph_bottom, IMAGE_WIDTH , BUTTON_HEIGHT);
    }else{
        // 非强制升级
        CGFloat borderWidth = 1.0;
        CGFloat buttonWidth = (IMAGE_WIDTH - borderWidth)/2.0;
        self.skipButton.frame = CGRectMake(0, self.bottomBorderLine.ph_bottom, buttonWidth, BUTTON_HEIGHT);
        self.upgradeButton.frame = CGRectMake(buttonWidth + 1, self.bottomBorderLine.ph_bottom, buttonWidth, BUTTON_HEIGHT);
        self.bottomMidLine.frame = CGRectMake(buttonWidth, self.bottomBorderLine.ph_bottom, borderWidth, BUTTON_HEIGHT);
    }
    //CGFloat contentH = 258 / 2 + self.contentLabel.ph_height + BUTTON_HEIGHT +  90;
    CGFloat imgH = 182;
    CGFloat titleTopMargin = 35;
    CGFloat titleHeight = 24;
    //CGFloat contentTopMargin = 6;
    //CGFloat contentHeight = 120;
    //CGFloat borderTopMargin = 24;
    //CGFloat borderHeight = 1.0;
    //BUTTON_HEIGHT
    CGFloat contentH = imgH + titleTopMargin + titleHeight + contentTopMargin + contentHeight + borderTopMargin + borderHeight + BUTTON_HEIGHT;
    CGFloat contentX = (PH_SCREEN_WIDTH - IMAGE_WIDTH) / 2;
    CGFloat contentY = (PH_SCREEN_HEIGHT - PH_STATUS_AND_NAVIGATION_HEIGHT - contentH)/2.0;
    if (PH_Is_iPhoneX) {
        contentY = contentY - PH_IPHONEX_BOTTOM_BAR/2.0;
    }
    self.contentView.frame = CGRectMake(contentX, contentY, IMAGE_WIDTH, contentH);
    CGFloat subY = imgH - 60;
    CGFloat subHeight = contentH - imgH + 60;
    //self.subView.frame = CGRectMake(0, self.headIcon.ph_bottom, IMAGE_WIDTH, contentH - self.headIcon.ph_height);
    self.subView.frame = CGRectMake(0, subY, IMAGE_WIDTH, subHeight);
    // 添加视图
    [self.contentView addSubview:self.headIcon];
    [self.contentView addSubview:self.subView];
    
    [self.subView addSubview:self.titleLabel];
    [self.subView addSubview:self.contentLabel];
    [self.subView addSubview:self.bottomBorderLine];
    [self.subView addSubview:self.skipButton];
    [self.subView addSubview:self.upgradeButton];
    [self.subView addSubview:self.bottomMidLine];
    // 将headIcon放到最上层呈现
    [self.contentView bringSubviewToFront:self.headIcon];
    
    // 添加毛玻璃效果
    //UIBlurEffect *blurEff = [UIBlurEffect effectWithStyle:(UIBlurEffectStyleDark)];
    // 创建显示的毛玻璃类
    //UIVisualEffectView *visualEffV = [[UIVisualEffectView alloc]initWithEffect:blurEff];
    UIView *visualEffV = [[UIView alloc] init];
    visualEffV.backgroundColor = [UIColor ph_colorWithHexString:@"#000000"];
    visualEffV.frame = self.bounds;
    visualEffV.alpha = 0.6;
    // 添加毛玻璃效果
    [self addSubview:visualEffV];
    // 添加升级视图
    [self addSubview:self.contentView];
    
}
#pragma make events

/**
 跳过按钮
 */
- (void)skipButtonAction{
    [self hideUpgradeView];
    
    [PH_USERDEFAULT setObject:self.versionModel.appVersionNum forKey:@"skipUpgrateVersion"];
}

/**
 升级按钮
 */
- (void)upgradeButtonAction{
    [PHAPPUpgradeView appVersionUpgradeCompulsively];
    //    if (!self.versionModel.mustUpgrade) {
    [self hideUpgradeView];
    //    }
}

/**
 升级
 */
+ (void)appVersionUpgradeCompulsively{
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *appUrl = [defaults objectForKey:@"appUrl"];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:appUrl]];
    
}

#pragma mark -util

/**
 隐藏升级视图
 */
- (void)hideUpgradeView{
    [self removeFromSuperview];
    
    // 保存弹窗状态
    //[PHUserDefaultsHandler setBool:NO key:kAppUpdatePopup];
}



- (NSMutableAttributedString *)setContentMargin:(NSString *)content{
    if(content.length == 0){
        return [[NSMutableAttributedString alloc]initWithString:@""];
    }
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:content];
    
    NSMutableParagraphStyle * paragraphStyle1 = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle1 setLineSpacing:5];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle1 range:NSMakeRange(0, content.length - 1)];
    
    return attributedString;
}

#pragma mark 资源获取
/** 从Bundle中获取图片 */
- (UIImage *)getImageFromBundle:(NSString *)name {
    UIImage *image = [UIImage imageNamed:[@"PHUpdateSDK.bundle/phupdate.bundle" stringByAppendingPathComponent:name]];
    if (image) {
        
        return image;
    } else {
        NSString *imgPath = [NSString stringWithFormat:@"%@/%@.png", [NSBundle bundleWithPath:[NSString stringWithFormat:@"%@/PHUpdateSDK.bundle/phupdate.bundle",[PH_BUNDLE_CLASS resourcePath]]], name];
        image =  [UIImage imageWithContentsOfFile:imgPath];
        
        if (!image) {
            NSString *imgPath = [NSString stringWithFormat:@"%@/phupdate.bundle/%@.png", [PH_BUNDLE_FRAMEWORK(@"PHUpdateSDK") resourcePath], name];
            image = [UIImage imageWithContentsOfFile:imgPath];
        }
        return image;
    }
}

@end
