//
//  PHAPPUpgradeView.h
//  PHMySDK
//
//  Created by Hu, Yuping on 2020/2/19.
//  Copyright © 2020 江苏云学堂信息科技有限公司. All rights reserved.
//

#import <PHBizCore/PHBaseView.h>

NS_ASSUME_NONNULL_BEGIN
@class PHVersionModel;
@interface PHAPPUpgradeView : PHBaseView

+ (PHAPPUpgradeView *)showUpgradeViewOnView:(UIView *)baseView withVersionModel:(PHVersionModel *)versionModel;
+ (PHAPPUpgradeView *)manullyShowUpgradeViewOnView:(UIView *)baseView withVersionModel:(PHVersionModel *)versionModel;

/**
 更新数据
 
 @param versionModel 版本升级数据模型
 */
- (void)updateDataWithModel:(PHVersionModel *)versionModel;

@end

NS_ASSUME_NONNULL_END
