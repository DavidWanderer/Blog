//
//  PHVersionModel.h
//  PHMySDK
//
//  Created by Hu, Yuping on 2020/2/19.
//  Copyright © 2020 江苏云学堂信息科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PHVersionModel : NSObject
/** APP版本号 */
@property (nonatomic, copy) NSString *appVersionNum;

/** APP下载url */
@property (nonatomic, copy) NSString *appUrl;

/** APP版本描述 */
@property (nonatomic, copy) NSString *appDescription;

/** HTML版本号 */
@property (nonatomic, copy) NSString *htmlVersionNum;

/** HTML下载url */
@property (nonatomic, copy) NSString *htmlUrl;

/** HTML版本描述 */
@property (nonatomic, copy) NSString *htmlDescription;

/** 是否需要升级 */
@property (nonatomic, assign) BOOL mustUpgrade;

@end

NS_ASSUME_NONNULL_END
